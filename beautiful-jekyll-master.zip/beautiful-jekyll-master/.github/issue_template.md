Please only submit feature suggestions or bug reports if you believe something is broken.

If you need help, you can attend the [Office Hours](https://beautifuljekyll.com/officehours) (only available for [sponsors](https://beautifuljekyll.com/plans/)).
